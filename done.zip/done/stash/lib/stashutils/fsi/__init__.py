# -*- coding: utf-8 -*-
"""
This package contains classes used for accessing filesystems or servers.
These classes have a common interface, which means they can easily be
switched.
"""