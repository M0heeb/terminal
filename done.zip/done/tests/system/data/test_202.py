# -*- coding: utf-8 -*-
from __future__ import print_function
print('The first line\nA quick brown fox jumps over the lazy dog\r\033[0P', end='')