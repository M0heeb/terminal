# -*- coding: utf-8 -*-
from __future__ import print_function
import os

print('from child script 2 {}'.format(os.path.basename(os.getcwd())))