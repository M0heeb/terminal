#!/bin/bash

# Ensure multiple commands on a single line work as expected
A=42; echo A is $A
