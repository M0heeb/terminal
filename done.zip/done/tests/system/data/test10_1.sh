#!/bin/bash

grep bash
