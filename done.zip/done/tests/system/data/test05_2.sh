#!/bin/bash
echo 2
echo B is $B
pwd -b
