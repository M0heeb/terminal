#!/bin/bash
echo 1
echo B is $B
B=89
echo B is $B
cd bin
pwd -b
